<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        footer {
            background-color: black;
            color: #fff;
            padding: 1rem;
            text-align: center;
        }
    </style>
</head>
<body>
    <?php
        echo '<footer>
            <p>&copy; 2024 Copyright: <b>FlexMatch</b>. All rights reserved.</p>
        </footer>'
    ?>
</body>
</html>